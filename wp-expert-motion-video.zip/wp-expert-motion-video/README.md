# WP Expert Solution — Facebook Page to Website (Remotion + React)

9:16 (1080×1920 @ 30 FPS) motion-design Facebook Reel for **WP Expert Solution**.

## Quick Setup

1. Place your original voice-over audio file at:
   `public/audio/voiceover.wav`
2. Install packages and auto-generate local WAV sound effects:
   ```bash
   npm install
   npm run setup
   ```

3. Preview in Remotion Studio:
   ```bash
   npm start
   ```

4. Render final MP4 locally:
   ```bash
   npm run render
   ```

---

## Asset Placement

1. **Voice-Over Audio (`public/audio/voiceover.wav`)**:
   - The word-level timestamp JSON (`cartesia_2026-10-21T15_15_40Z_Rupam_sonic-3.6_bn-BD.json`, spanning `0.20s` to `122.12s`) and reference video were analyzed directly, and every word timestamp from `cartesia_2026-10-21T15_15_40Z_Rupam_sonic-3.6_bn-BD.json` is baked directly into `src/data/captions.ts` and `src/data/scenes.ts`.
   - Copy your corresponding recording (`cartesia_2026-10-21T15_15_40Z_Rupam_sonic-3.6_bn-BD.wav`) to:
     ```text
     public/audio/voiceover.wav
     ```
   - *(Note: If you place `cartesia_2026-10-21T15_15_40Z_Rupam_sonic-3.6_bn-BD.wav` in the project root before running `npm run setup`, `scripts/generate-sfx.js` will automatically copy it to `public/audio/voiceover.wav`.)*

2. **Generated SFX Assets (`public/sfx/*.wav`)**:
   - Running `npm run setup` (or `npm start` / `npm run render`, which trigger `prestart` and `prerender` automatically) executes `scripts/generate-sfx.js` to deterministically generate all 9 `.wav` sound effects (`pop.wav`, `click.wav`, `whoosh.wav`, `ding.wav`, `warning.wav`, `success.wav`, `reveal.wav`, `chime.wav`, `tick.wav`) inside `public/sfx/`.

---

## Minimal Local Setup Instructions

```bash
# 1. Install dependencies
npm install

# 2. Generate the local WAV sound effects in public/sfx/
npm run setup

# 3. Open Remotion Studio to preview on timeline
npm start

# 4. Render the final 1080x1920 @ 30fps MP4 locally
npm run render
```
